# DiDiWeather —— 天气预报Android APP
这是一个简单的天气预报软件。可以根据地点显示当前和未来七天的天气情况，显示空气质量和生活建议。  

### 安装环境
·Android stusio 2.2  

### 功能设计图
![ ](https://images.gitee.com/uploads/images/2020/1122/174000_9d732922_8134479.png "屏幕截图.png")  

### 效果展示
#### 1.第一次进入软件：选择省市县  
![选择省](https://images.gitee.com/uploads/images/2020/1122/174041_ab476a76_8134479.png "屏幕截图.png")
![选择市](https://images.gitee.com/uploads/images/2020/1122/174054_59628ff1_8134479.png "屏幕截图.png")
![选择县](https://images.gitee.com/uploads/images/2020/1122/174106_80057e74_8134479.png "屏幕截图.png")
#### 2.进入软件主页面显示天气  
##### ·主体图  
![主体图](https://images.gitee.com/uploads/images/2020/1122/174431_8016feff_8134479.png "屏幕截图.png")
![主体图](https://images.gitee.com/uploads/images/2020/1122/174437_a6406dae_8134479.png "屏幕截图.png")  
##### ·显示当前地区和当前天气情况  
![显示当前地区](https://images.gitee.com/uploads/images/2020/1122/174458_479b3c33_8134479.png "屏幕截图.png")
![当前天气情况](https://images.gitee.com/uploads/images/2020/1122/174537_b20aff67_8134479.png "屏幕截图.png")  
##### ·显示未来七天天气情况  
![未来七天天气情况](https://images.gitee.com/uploads/images/2020/1122/174553_fcf0060a_8134479.png "屏幕截图.png")  
##### ·显示空气质量和生活建议  
![空气质量情况](https://images.gitee.com/uploads/images/2020/1122/174613_fd595760_8134479.png "屏幕截图.png")
![生活建议](https://images.gitee.com/uploads/images/2020/1122/174636_1a9dfae8_8134479.png "屏幕截图.png")
#### 3.右滑重新选择地区  
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175009_a7b24cae_8134479.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175014_d9d1128d_8134479.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175021_ef2ae390_8134479.png "屏幕截图.png")
#### 4.手动刷新天气情况（8小时会自动刷新）  
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175057_aebc4829_8134479.png "屏幕截图.png")  
#### 5.点击右上角获取联系方式  
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175121_74eeac37_8134479.png "屏幕截图.png")  
#### 6.当网络不好时的交互效果  
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175153_6970e7bc_8134479.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1122/175159_abbb5b5b_8134479.png "屏幕截图.png")  

### 参考文献
·郭霖老师的《第一行代码》