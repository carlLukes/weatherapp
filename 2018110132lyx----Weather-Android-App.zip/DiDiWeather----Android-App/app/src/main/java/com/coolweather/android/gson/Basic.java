package com.coolweather.android.gson;

import com.google.gson.annotations.SerializedName;

/**
 * Created by biu on 2020/10/6.
 * cityName,weatherId,update.updateTime
 */

public class Basic {

    @SerializedName("city")
    public String cityName;

    @SerializedName("id")
    public String weatherId;

    public Update update;

    public class Update {

        @SerializedName("loc")
        public String updateTime;

    }

}

