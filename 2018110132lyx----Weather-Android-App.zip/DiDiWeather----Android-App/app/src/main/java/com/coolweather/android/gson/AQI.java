package com.coolweather.android.gson;

/**
 * Created by biu on 2020/10/6.
 * city.aqi,city.pm25
 */

public class AQI {

    public AQICity city;

    public class AQICity {

        public String aqi;

        public String pm25;

    }
}