package com.coolweather.android.gson;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by biu on 2020/10/6.
 * 是总的实例类，用来引用其他5个实体类
 * status(String),basic(Basic),aqi(AQI),now(Now),suggestion(Suggestion),forecastList(List<Forecast>)
 */


public class Weather {

    public String status;

    public Basic basic;

    public AQI aqi;

    public Now now;

    public Suggestion suggestion;

    @SerializedName("daily_forecast")
    public List<Forecast> forecastList;

}
